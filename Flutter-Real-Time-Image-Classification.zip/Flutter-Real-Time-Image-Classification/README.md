For details: https://medium.com/@krishnarajr319/real-time-image-classification-on-android-using-flutter-tflite-2674f03caf0f





# flutter-realtime-image-classification

Real-time Image Classification in Flutter using [camera](https://pub.dartlang.org/packages/camera) and [tflite](https://pub.dartlang.org/packages/tflite) plugin. 

## Install 

```
flutter packages get
```

## Run

```
flutter run
```
